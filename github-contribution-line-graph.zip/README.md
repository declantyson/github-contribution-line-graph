# GitHub Contribution Line Graph

Chrome Extension to add a line graph underneath the standard contributions

![Screenshot](https://raw.githubusercontent.com/declantyson/github-contribution-line-graph/master/screenshot.png)

### Why?

why not

### But I could do this myself in about 10 minutes!

cool

### It also seems really inefficient

don't really care

### Will you ever update this to include any actual functionality?

probs not